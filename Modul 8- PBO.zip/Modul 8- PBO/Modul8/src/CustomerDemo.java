/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LABRPL-26
 */
public class CustomerDemo {
    public static void main(String[] args){
        CustomerData m1 = new CustomerData();
        m1.setNama("Dwi Alvian");
        m1.setGaji(4000000);
        m1.setAlamat("Sragen");
        m1.setTanggalLahir("25 September 2000");
        m1.setPekerjaan("Programer");
        System.out.println("Nama : " + m1.getNama());
        System.out.println("Alamat : " + m1.getAlamat());
        System.out.println("Tanggal Lahir : " + m1.getTanggalLahir());
        System.out.println("Pekerjaan : " + m1.getPekerjaan());
        System.out.println("Gaji : " + m1.getGaji());
        
        System.out.println("\n");
        
        CustomerData m2 = new CustomerData();
        m2.setNama("Jing");
        m2.setGaji(3500000);
        m2.setAlamat("Klaten");
        m2.setTanggalLahir("2 November 2000");
        m2.setPekerjaan("Programer");
        System.out.println("Nama : " + m2.getNama());
        System.out.println("Alamat : " + m2.getAlamat());
        System.out.println("Tanggal Lahir : " + m2.getTanggalLahir());
        System.out.println("Pekerjaan : " + m2.getPekerjaan());
        System.out.println("Gaji : " + m2.getGaji());
        
    }
    
}
