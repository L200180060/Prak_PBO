/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LABRPL-26
 */
public class ElangDemo {
    public static void main (String[] args){
    elang e = new elang();
    
    e.kasihNama("HAWK");
    
    System.out.println(
        e.panggilnama()+"\n"+
        e.jalan());
    }
}