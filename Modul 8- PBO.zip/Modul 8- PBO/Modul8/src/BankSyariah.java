/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class BankSyariah extends BankUmum{
    protected int rasioBunga(){
        return 0;
    }
}
