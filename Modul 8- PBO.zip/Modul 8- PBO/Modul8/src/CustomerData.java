/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LABRPL-26
 */
public class CustomerData {
    private String nama;
    private String alamat;
    private String TanggalLahir;
    private String pekerjaan;
    private int gaji;
    
    public String getNama(){
        return nama;
    }
    
    public void setNama(String nama){
        this.nama = nama;
    }
    
    public String getAlamat(){
        return alamat;
    }
    
    public void setAlamat(String alamat){
        this.alamat = alamat;
    }
    
    public String getTanggalLahir(){
        return TanggalLahir;
    }
    
    public void setTanggalLahir(String TanggalLahir){
        this.TanggalLahir = TanggalLahir;
    }
    
    public String getPekerjaan(){
        return pekerjaan;
    }
    
    public void setPekerjaan(String pekerjaan){
        this.pekerjaan = pekerjaan;
    }
    
    public int getGaji(){
        return gaji;
    }
    
    public void setGaji(int gaji){
        this.gaji = gaji;
    }
}
