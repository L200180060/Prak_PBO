public class BungaDemo{
	public static void main(String[] args){
		Bunga bunga = new Bunga();
		bunga.beriWarna("Merah");
		bunga.beriJenis("Mawar");
		bunga.timbangBerat(15);
		bunga.hargaJual(7000);
		bunga.infoBunga();
	}
}