public class RotiDemo{
	public static void main(String[] args){
		Roti roti = new Roti();
		roti.beriWarna("putih");
		roti.beriRasa("coklat");
		roti.timbangBerat(30);
		roti.hargaJual(3000);
		roti.infoRoti();
	}
}