public class Bunga{
	String warna;
	String jenis;
	int berat;
	double harga;

	void beriWarna(String warnaBunga){
		warna = warnaBunga;
	}

	void beriJenis(String jenisBunga){
		jenis = jenisBunga;
	}

	void timbangBerat(int beratBunga){
		berat = beratBunga;
	}

	void hargaJual(double hargaBunga){
		harga = hargaBunga;
	}

	void infoBunga() {
		System.out.println(
			"Warna Bunga :" + warna + "\n" +
			"Jenis Bunga :" + jenis + "\n"+
			"Berat Bunga :" + berat + "\n"+ "gr"+
			"Harga Bunga : Rp. " + harga) ;
	}
}