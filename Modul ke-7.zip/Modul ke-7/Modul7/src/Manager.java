/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LABRPL-23
 */
public class Manager extends Karyawan{
    private float jamKerja = 7.5f;
    
    public int jamKerja(){
        return (int)jamKerja;
    }
    public float getGajiManager(){
        return getGaji()*2;
    }
    public void SetjamKerja(float jamKerja){
        this.jamKerja = jamKerja;
    }
}
