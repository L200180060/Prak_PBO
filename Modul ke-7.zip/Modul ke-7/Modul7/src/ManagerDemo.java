/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LABRPL-23
 */
public class ManagerDemo {
   public static void main(String[] args){
       Manager m1 = new Manager();
       Manager m2 = new Manager();
       Manager m3 = new Manager();
       Manager m4 = new Manager();
       Manager m5 = new Manager();
       
       m1.setNama("Willi Susanti");
       m1.setGaji(2000000);
       m1.setUsia(19);
       m1.SetjamKerja(8.5f);
       System.out.println("Manager 1:"+ m1.getNama());
       System.out.println("Gaji Manager 1:"+ m1.getGajiManager());
       System.out.println("Usia Manager 1:"+ m1.getUsia());
       System.out.println("Jam Kerja:"+ m1.jamKerja());
       
       m2.setNama("Willi");
       m2.setGaji(2500000);
       m2.setUsia(19);
       m2.SetjamKerja(8.5f);
       System.out.println("Manager 2:"+ m2.getNama());
       System.out.println("Gaji Manager 2:"+ m2.getGajiManager());
       System.out.println("Usia Manager 2:"+ m2.getUsia());
       System.out.println("Jam Kerja:"+ m2.jamKerja());
       
       m3.setNama("Susan");
       m3.setGaji(1950000);
       m3.setUsia(19);
       m3.SetjamKerja(8.5f);
       System.out.println("Manager 3:"+ m3.getNama());
       System.out.println("Gaji Manager 3:"+ m3.getGajiManager());
       System.out.println("Usia Manager 3:"+ m3.getUsia());
       System.out.println("Jam Kerja:"+ m3.jamKerja());
       
       m4.setNama("Santi");
       m4.setGaji(2100000);
       m4.setUsia(19);
       m4.SetjamKerja(8.5f);
       System.out.println("Manager 4:"+ m4.getNama());
       System.out.println("Gaji Manager 4:"+ m4.getGajiManager());
       System.out.println("Usia Manager 4:"+ m4.getUsia());
       System.out.println("Jam Kerja:"+ m4.jamKerja());
       
       m5.setNama("CINDYL");
       m5.setGaji(50000);
       m5.setUsia(19);
       m5.SetjamKerja(8.5f);
       System.out.println("Manager 5:"+ m5.getNama());
       System.out.println("Gaji Manager 5:"+ m5.getGajiManager());
       System.out.println("Usia Manager 5:"+ m5.getUsia());
       System.out.println("Jam Kerja:"+ m5.jamKerja());
   }
            
}
