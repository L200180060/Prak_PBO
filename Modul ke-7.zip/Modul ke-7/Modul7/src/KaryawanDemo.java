/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LABRPL-23
 */
public class KaryawanDemo {
    public static void main(String[] args){
        Karyawan k = new Karyawan();
        k.setNama("Willi");
        k.setGaji(2500000);
        k.setUsia(19);
        System.out.println(k.getNama());
        System.out.println(k.getGaji());
        System.out.println(k.getUsia());
    }
}
