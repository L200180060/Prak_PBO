public class Dosen{
	String nama;
	int nik;
	String pendidikan;
	String tglLahir;

	void tampilkanNama(String namaDosen){
		nama = namaDosen;
	}

	void tampilkanNik(int nikDosen){
		nik = nikDosen;
	}

	void tampilkanPendidikan(String pendidikanDosen){
		pendidikan = pendidikanDosen;
	}

	void tampilkanTglLahir(String tglLahirDosen){
		tglLahir = tglLahirDosen;
	}
	
	void infoDosen(){
		System.out.println(
			"Nama Dosen :" + nama + "\n" +
			"Nik Dosen :" + nik + "\n" +
			"Pendidikan Dosen :" + pendidikan + "\n" +
			"TglLahir Dosen :" + tglLahir);
	}
}