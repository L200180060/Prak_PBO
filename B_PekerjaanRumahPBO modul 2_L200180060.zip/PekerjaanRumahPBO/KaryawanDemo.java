public class KaryawanDemo{
	public static void main(String[] args){
		Karyawan karyawan  = new Karyawan();
		karyawan.tampilkanNama("Suryo");
		karyawan.tampilkanAlamat("Jambean");
		karyawan.tampilkanJabatan("Ketua Mahasiswa");
		karyawan.jumlahGaji(1000);
		karyawan.infoKaryawan();
	}
}