public class Mahasiswa{
	String nama;
	String nim;
	String alamat;
	int semester;

	void tampilkanNama(String namaMahasiswa){
		nama = namaMahasiswa;
	}
	
	void tampilkanNim(String nimMahasiswa){
		nim = nimMahasiswa;
	}

	void tampilkanAlamat(String alamatMahasiswa){
		alamat = alamatMahasiswa;
	}

	void jumlahSemester(int semesterMahasiswa){
		semester = semesterMahasiswa;
	}

	void infoMahasiswa() {
		System.out.println(
			"Nama Mahasiswa :" + nama + "\n" +
			"Nim Mahasiswa :" + nim + "\n" +
			"Alamat Mahasiswa :" + alamat + "\n"+
			"Jumlah Semester :" + semester) ;
	}
}