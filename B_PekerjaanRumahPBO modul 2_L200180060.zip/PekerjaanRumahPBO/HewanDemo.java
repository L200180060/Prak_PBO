public class HewanDemo{
	public static void main(String[] args) {
		Hewan hewan1 = new Hewan();
		Hewan hewan2 = new Hewan();

		hewan1.Namahewan("harimau");
		hewan1.Jumlahkaki(4);
		hewan1.Makanan("daging");
		hewan1.Jenis("karnivora");
		hewan1.printInfo();

		hewan2.Namahewan("kerbau");
		hewan2.Jumlahkaki(4);
		hewan2.Makanan("rumput");
		hewan2.Jenis("herbifora");
		hewan2.printInfo();
	}
}