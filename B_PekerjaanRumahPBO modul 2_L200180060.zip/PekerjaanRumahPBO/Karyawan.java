public class Karyawan{
	String nama;
	String alamat;
	String jabatan;
	double gaji;

	void tampilkanNama(String namaKaryawan){
		nama = namaKaryawan;
	}

	void tampilkanAlamat(String alamatKaryawan){
		alamat = alamatKaryawan;
	}

	void tampilkanJabatan(String jabatanKaryawan){
		jabatan = jabatanKaryawan;
	}

	void jumlahGaji(double gajiKaryawan){
		gaji = gajiKaryawan;
	}

	void infoKaryawan() {
		System.out.println(
			"Nama Karyawan :" + nama + "\n" +
			"Alamat Karyawan :" + alamat + "\n"+
			"Jabatan Karyawan :" + jabatan + "\n"+ "gr"+
			"Jumlah gaji : Rp. " + gaji) ;
	}
}