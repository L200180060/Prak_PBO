public class Hewan{
	String nama;
	int jumlahkaki;
	String makanan;
	String typehewan;

	void Namahewan(String namaHewan){
		nama = namaHewan;
	}

	void Jumlahkaki(int jumlahkakiHewan){
		jumlahkaki = jumlahkakiHewan;
	}

	void Makanan(String makananHewan ){
		makanan = makananHewan;
	}

	void Jenis(String typeHewan){
		typehewan = typeHewan;
	}

	void printInfo() {
		System.out.println(
			"Nama Hewan :" + nama + "\n" +
			"Jumlah Kaki :" + jumlahkaki + "\n"+
			"Makanan  :" + makanan + "\n"+ 
			"Type Hewan : " + typehewan) ;
	}
}