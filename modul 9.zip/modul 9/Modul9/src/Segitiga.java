/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Personal
 */
public class Segitiga extends methodAbstract {
    int alas = 5;
    int tinggi =2;
    
    public int luas(){
        return alas*tinggi/2;
    }
    public int keliling(){
        return 3*alas;
    }
}
