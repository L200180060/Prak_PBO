/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Personal
 */
public class ObjekAbstrakClasss {
    public static void main(String[] args){
        TurunanAbstrakClass tac = new TurunanAbstrakClass(2,3,2);
        tac.printX();
        System.out.println(tac.kali());
        
    }
}
