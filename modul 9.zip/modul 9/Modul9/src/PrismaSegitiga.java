/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Personal
 */
public class PrismaSegitiga extends methodAbstrak {
    int alas = 6;
    int tAlas = 6;
    int tPrisma = 10;
    
    public int luasPermukaan(){
        return(alas*tAlas)+3*alas*tPrisma;
    }
    public int volume(){
        return 1/2*alas*tAlas*tPrisma;
    }
}
