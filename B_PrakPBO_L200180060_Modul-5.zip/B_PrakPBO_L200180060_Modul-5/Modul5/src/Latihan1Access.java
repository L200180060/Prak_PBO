/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bayu
 */
public class Latihan1Access {
    public static void main(String[] args){
        Latihan1 lt1 = new Latihan1();
        
    }
}
