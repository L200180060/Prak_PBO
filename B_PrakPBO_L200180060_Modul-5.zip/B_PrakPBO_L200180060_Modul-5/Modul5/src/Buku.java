/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LABRPL-8
 */
public class Buku {
    String namaPengarang, judulBuku;
    int tahunTerbit, cetakanKe;
    double hargaJual;
Buku(){
    System.out.println("Selamat Datang Di Toko Buku Anugrah");
}
Buku(String judulBuku, String namaPengarang){
    this();
    System.out.println("Judul Buku : " + judulBuku + "\n" +
                       "Nama Pengarang : " + namaPengarang);
}

Buku(String judulBuku, String namaPengarang,int tahunTerbit){
    this(judulBuku, namaPengarang);
    System.out.println("Tahun Terbit : " + tahunTerbit);
    
}

Buku(String judulBuku, String namaPengarang,int tahunTerbit, int cetakanKe){
    this(judulBuku, namaPengarang, tahunTerbit);
    System.out.println("Cetakan Ke : " + cetakanKe);
}

Buku(String judulBuku, String namaPengarang,int tahunTerbit, int cetakanKe, double hargaJual){
    this(judulBuku, namaPengarang, tahunTerbit, cetakanKe);
    System.out.println("Harga Jual : Rp. " + hargaJual + "\n");
}

public static void main(String[] args){
    Buku bk1 = new Buku("PBO","Dyah Priyawati",2019,1,60000);
    Buku bk2 = new Buku("Laskar Pelangi","Andrea",2015,1,70000);
    Buku bk3 = new Buku("Dear Nathan","Erisca",2017,1,62000);
    Buku bk4 = new Buku("Cinta Brontosaurus","Raditya Dika",2015,1,77000);
    Buku bk5 = new Buku("Menembus Impian","Abidah",2017,2,25000);
    Buku bk6 = new Buku("Merpati Biru","Ahmad",2018,1,43000);
    Buku bk7 = new Buku("Kepompong","Indah",2006,1,59000);
    Buku bk8 = new Buku("Kupu-kupu","Putut",2015,1,50000);
    Buku bk9 = new Buku("Sepucuk Surat","Susanto",2019,1,80000);
    Buku bk10 = new Buku("Surat Dari Kota","Susanto",2019,1,90000);
}
}
