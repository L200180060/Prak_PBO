/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;

/**
 *
 * @author LABRPL-13
 */
public class Teknisi extends Pegawai {
    public static void main (String[] args ){
    double lemburPerjam = 40000;
    double gajiPerBulan;
    Pegawai p = new Pegawai();
    gajiPerBulan = p.gajipokok + lemburPerjam;
    System.out.println(gajiPerBulan);
    }
}
