/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;

/**
 *
 * @author Asus
 */
public class segitiga extends bangundatar{
    double alas;
    double tinggi;
    double sisi;
    double luas (){
        double luas = ((alas * tinggi)/2);
        System.out.println("luas Segitiga :" + luas);
        return luas;
    }   
    double keliling (){
        double keliling = (alas + tinggi + sisi);
        System.out.println("Keliling Segitiga :" + keliling);
        return keliling;
    }
    
}
