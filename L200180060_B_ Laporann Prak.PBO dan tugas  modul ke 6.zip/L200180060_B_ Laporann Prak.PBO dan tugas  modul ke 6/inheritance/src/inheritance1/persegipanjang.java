/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;

/**
 *
 * @author Asus
 */
public class persegipanjang extends bangundatar {
    int panjang;
    double lebar;
    double luas (){
        double luas = (panjang * lebar);
        System.out.println("luas Persegi panjang :" + luas);
        return luas;
    }   
    double keliling (){
        double keliling = ( 2*(panjang + lebar));
        System.out.println("Keliling Persegipanjang :" + keliling);
        return keliling;
    }
}
