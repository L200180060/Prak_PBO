/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;

/**
 *
 * @author Asus
 */
public class segitigasamakaki extends segitiga {
    double sisimiring;
    double sisi;
    double alas;
    double tinggi;
    double luas (){
        double luas = ((alas * tinggi)/2);
        System.out.println("luas Segitiga sama kaki:" + luas);
        return luas;
    }   
    double keliling (){
        double keliling = (alas + tinggi + sisimiring);
        System.out.println("Keliling Segitiga sama kaki :" + keliling);
        return keliling;
    }
}
