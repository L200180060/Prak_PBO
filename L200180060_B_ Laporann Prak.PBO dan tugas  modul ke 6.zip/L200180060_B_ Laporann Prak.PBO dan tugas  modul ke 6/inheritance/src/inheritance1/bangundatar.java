/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;

/**
 *
 * @author Asus
 */
public class bangundatar {
    double luas(){
        System.out.println ("ini method untuk menghitung luas");
        return 0;
    }
    double keliling(){
        System.out.println("ini method untuk menghitung keliling");
        return 0;
    }
    public static void main (String[] args){
        bangundatar bd = new bangundatar();
        persegi p = new persegi ();
        p.sisi = 6;
        persegipanjang pp = new persegipanjang();
        pp.panjang = 8;
        pp.lebar = 5;
        segitiga s = new segitiga();
        s.alas = 18;
        s.tinggi = 9 ;
        segitigasamakaki sk = new segitigasamakaki();
        sk.sisimiring = 8;
        sk.alas = 10;
        sk.sisi = 5;
        sk.tinggi = 6;
        segitigasamasisi ss = new segitigasamasisi();
        ss.sisi = 10;
        ss.alas = 8;
        ss.tinggi = 5;
        
        bd.luas();
        bd.keliling();
        p.luas();
        p.keliling();
        pp.luas();
        pp.keliling();
        s.luas();
        s.keliling();
        sk.luas();
        sk.keliling();
        ss.luas();
        ss.keliling();
    }
}
