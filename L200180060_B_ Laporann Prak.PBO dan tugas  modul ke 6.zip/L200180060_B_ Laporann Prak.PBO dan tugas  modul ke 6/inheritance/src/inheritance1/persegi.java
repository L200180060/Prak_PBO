/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;

/**
 *
 * @author Asus
 */
public class persegi extends bangundatar{
    double sisi;
    double luas (){
        double luas =  sisi * sisi;
        System.out.println("luas persegi :" + luas);
        return luas;
    }   
    double keliling (){
        double keliling = 4 * sisi;
        System.out.println("Keliling Persegi :" + keliling);
        return keliling;
    }
}
