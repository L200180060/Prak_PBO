/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;


public class mainKendaraan {
    public static void main(String[] args){
        String data;
        Mobil m = new Mobil();
        System.out.println(m.jenis);
        System.out.println(m.warna);
        System.out.println(m.roda);
        System.out.println(m.jumlahkursi);
        
        Pesawat p = new Pesawat();
        System.out.println(p.jenis);
        System.out.println(p.warna);
        System.out.println(p.roda);
        System.out.println(p.jumlahpenumpang);
        
        Kendaraan k = new Kendaraan();
        System.out.println(k.jenis);
        System.out.println(k.warna);
        System.out.println(k.roda);
    }
}
